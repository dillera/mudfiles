char *index(char *s, char c) {  return (char *)strchr(s,c); }
char *rindex(char *s, char c) { return (char *)strrchr(s,c); }

