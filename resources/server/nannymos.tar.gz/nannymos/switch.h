#define ZERO_AS_STR_CASE_LABEL NULL /* This value musn't be misinterpreted as
				     * shared string. When string handling is
				     * changed, change this value appropriately
				     */
