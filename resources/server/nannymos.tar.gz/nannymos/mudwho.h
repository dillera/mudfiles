/*
 * configuration file for mudwho entry update
 * This is ONLY AN EXAMPLE! You have to talk to a server admin about your
 * mud-internet-address, the name you will put in here and the password
 * you want to use.
 */

/* The ip-address of your mudwho server */
#define MUDWHO_SERVER "130.236.254.150"


#define	DGRAMPORT		6888

/* The name of your mud (The server admin must know it, too) */
#define MUDWHO_NAME "NannyMUD"

/* The password you use for your mud to connect to the server */
#define MUDWHO_PASSWORD "auharregud"

/* How often LPmud sends out the "I'm still alive" packet and player list */
#define MUDWHO_REFRESH_TIME 100
