#define VERSION_STRING \
"GNU indent 1.0.  Based on Berkeley indent 5.11 (9/15/88)."
