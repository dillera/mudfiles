struct wiz_list {
    char *name;
    int length;
    struct wiz_list *next;
    int score;
    int cost;
    int heart_beats;
    int call_outs;
    int total_worth;
    int size_array;		/* Total size of this wizards arrays. */
    /*
     * The following values are all used to store the last error
     * message.
     */
    char *file_name;
    char *error_message;
    int line_number;
};

extern struct wiz_list *add_name PROT((char *));
struct value;
extern void save_wiz_file(), load_wiz_file(), wiz_decay();
