extern void efun_acl_num2str(struct svalue *sp);
extern void efun_acl_put(struct svalue *sp);
extern void efun_acl_str2num(struct svalue *sp);
extern void efun_acl_get(struct svalue *sp);
extern void efun_acl_modify(struct svalue *sp);
extern void efun_acl_access(struct svalue *sp, int args);
extern void efun_acl_debug(struct svalue *sp);
