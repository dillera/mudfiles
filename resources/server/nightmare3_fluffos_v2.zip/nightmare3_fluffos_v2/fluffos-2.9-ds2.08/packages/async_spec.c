#include "spec.h"

void async_read(string, function);
void async_write(string, string, function);
