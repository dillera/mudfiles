#include "spec.h"

string query_multiple_short(mixed *, int | string | void, int | void, int | void, int | void);
int reference_allowed(object, string | object | void);
int roll_MdN( int, int );
string add_a( string );
int vowel( int );
string replace(string, string *|string, string|void);
string replace_html(string);
string replace_mxp(string);
