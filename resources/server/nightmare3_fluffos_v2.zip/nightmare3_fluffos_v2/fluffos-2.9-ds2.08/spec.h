/* This is the correct file to include in efun specification files; e.g.
   func_spec.c and packages/anything_spec.c */

#define _FUNC_SPEC_
#include "std.h"
