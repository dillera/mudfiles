void foo {
    ({ })[1];
}
