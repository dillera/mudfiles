class foo {
    int x;
}

class foo {
    string y;
}
