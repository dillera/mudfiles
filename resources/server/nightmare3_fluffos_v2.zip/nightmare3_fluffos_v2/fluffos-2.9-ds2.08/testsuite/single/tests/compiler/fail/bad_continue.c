void foo() {
    continue;
}
