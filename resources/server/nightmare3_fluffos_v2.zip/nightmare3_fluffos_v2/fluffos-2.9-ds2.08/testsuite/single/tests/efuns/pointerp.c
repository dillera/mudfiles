void do_tests() {
    ASSERT(pointerp( ({}) ));
    ASSERT(!pointerp( ([]) ));
}
