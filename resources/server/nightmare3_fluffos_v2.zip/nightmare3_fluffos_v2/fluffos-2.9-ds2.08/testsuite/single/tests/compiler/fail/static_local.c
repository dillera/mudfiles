void main() {
    static int x = 5;
}
