void do_tests() {
    for (int i = 0; i < 100; i++) {
	ASSERT(random(5) >= 0);
	ASSERT(random(5) < 5);
    }
}
