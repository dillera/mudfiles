
int
clean_up(int inh)
{
	destruct(this_object());
	return 0;
}
