unsigned uvalarm(unsigned int, unsigned int);
