#include <armor_types.h>
int armor() { return A_AMULET; }
