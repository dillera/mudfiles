#include <damage_types.h>
int damage() { return DEATHRAY; }
