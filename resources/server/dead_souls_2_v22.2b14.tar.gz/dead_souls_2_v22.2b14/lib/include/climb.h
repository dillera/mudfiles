#ifndef s_climb_h
#define s_climb_h

#define CLIMB_UP          1
#define CLIMB_DOWN        2
#define CLIMB_OUT         3
#define CLIMB_INTO        4
#define CLIMB_THROUGH     5

#endif /* s_climb_h */
