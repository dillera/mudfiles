#ifndef s_magic_h
#define s_magic_h

#define SPELL_HEALING       1
#define SPELL_DEFENSE       2
#define SPELL_COMBAT        3
#define SPELL_OTHER         4

#endif // s_magic_h


   
