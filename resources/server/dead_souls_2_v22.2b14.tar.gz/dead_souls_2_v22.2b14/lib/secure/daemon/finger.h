#ifndef __FINGER_H__
#define __FINGER_H__

static void create();
varargs string GetFinger(string who);
string GetTitle();

#endif /* __FINGER_H__ */
