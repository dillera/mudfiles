#ifndef s_lvs_h
#define s_lvs_h

#include <dirs.h>

#define LIB_ABILITIES      DIR_LVS "/abilities"
#define LIB_POSITION       DIR_LVS "/position"

#endif /* s_lvs_h */
