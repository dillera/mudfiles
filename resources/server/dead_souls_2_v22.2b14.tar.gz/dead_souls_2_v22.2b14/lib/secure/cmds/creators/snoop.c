/*
// The snoop command.
// Daemonized by Buddha (2-19-92)
// Part of the TMI mudlib.
*/

#include <lib.h>
#include <daemons.h>

inherit LIB_DAEMON;

int cmd(string str) {
    object ob;

    if( !str || str == "" ) {
	write("Snoop whom?\n");
    }
    else if(str == this_player()->GetKeyName()){
	write("That would be very foolish.");
	return 1;
    }
    else if(!(ob=find_player(str=lower_case(str))))
	write(str+": no such player.\n");
    else
	SNOOP_D->AddWatcher(this_player()->GetKeyName(), str);
    write("The snoop daemon has received your request.");
    return 1;
}

int help()
{
    write( @EndText
Syntax: snoop <user>
Effect: Echoes to your screen everything <user> sees or types.
        To stop snooping, type just "unsnoop <user>"
See also: unsnoop, monitor, unmonitor
EndText
    );
    return 1;
}
