#ifndef __EDITOR_H__
#define __EDITOR_H__

varargs void eventEdit(string file, function callback);
static string process_input(string cmd);

#endif /* __EDITOR_H__ */
