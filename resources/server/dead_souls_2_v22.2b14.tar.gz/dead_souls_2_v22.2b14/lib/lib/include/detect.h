#ifndef __detect_h__
#define __detect_h__

int direct_detect_wrd_in_obj(string word);
mixed eventDetect(object who, string str, int ability);

/* virtuals */

mixed GetProperty(string str);
string GetShort();

#endif
