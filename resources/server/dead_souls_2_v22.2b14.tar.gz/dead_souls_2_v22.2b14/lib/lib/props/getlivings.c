/*    /lib/props/getlivings.c
 *    From the Frontiers LPC Library
 *     this was an ugly hack to return an array of living things. now sefun
 *    Give it an integer argument to return interactives only
 *    Created by Cratylus 15JAN2005
 *    Version: @(#) getlivings.c 1.1@(#)
 *    Last modified: 2005/01/15
 */

