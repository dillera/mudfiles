#ifndef l_search_h
#define l_search_h

static void create();

mixed can_search();
mixed can_search_obj();

mixed do_search();
varargs mixed do_search_obj(object ob, mixed *args...);

#endif /* l_search_h */
