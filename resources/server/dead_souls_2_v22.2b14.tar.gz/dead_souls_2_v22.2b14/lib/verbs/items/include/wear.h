#ifndef l_wear_h
#define l_wear_h

static void create();

mixed can_wear_obj();
mixed can_wear_obj_on_str(string str);

mixed do_wear_obj(object ob);
mixed do_wear_obj_on_str(object ob, string str);

#endif /* l_wear_h */
