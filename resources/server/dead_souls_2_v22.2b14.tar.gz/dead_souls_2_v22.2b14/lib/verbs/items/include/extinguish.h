#ifndef l_extinguish_h
#define l_extinguish_h

static void create();

mixed can_extinguish_obj();

mixed do_extinguish_obj(object target);
mixed do_extinguish_obs(mixed *targs);

#endif /* l_extinguish_h */
