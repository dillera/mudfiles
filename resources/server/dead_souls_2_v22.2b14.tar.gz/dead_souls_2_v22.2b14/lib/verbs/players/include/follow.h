#ifndef l_follow_h
#define l_follow_h

static void create();
mixed can_follow();
mixed do_follow();
mixed can_follow_liv();
mixed do_follow_liv(object ob);

#endif /* l_follow_h */


