#ifndef l_bump_h
#define l_bump_h
 
static void create();
mixed can_bump_liv();
mixed do_bump_liv(object ob);
void MoveBack(object ob, string where);
 
#endif /* l_bump_h */
