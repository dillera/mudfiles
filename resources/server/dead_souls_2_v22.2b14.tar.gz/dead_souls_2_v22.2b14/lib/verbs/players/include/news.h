
static void create();
mixed can_news();
mixed can_news_str(string str);
mixed do_news();
mixed do_news_str(string str);


