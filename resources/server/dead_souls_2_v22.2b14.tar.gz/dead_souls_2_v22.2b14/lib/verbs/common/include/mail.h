#ifndef l_mail_h
#define l_mail_h

static void create();

mixed can_mail();
mixed can_mail_str(string str);

mixed do_mail();
mixed do_mail_str(string str);

string GetHelp(string str);

#endif /* l_mail_h */
