#ifndef EFUNS_INCL_H
#define EFUNS_INCL_H

#include "efun_protos.h"

#endif
