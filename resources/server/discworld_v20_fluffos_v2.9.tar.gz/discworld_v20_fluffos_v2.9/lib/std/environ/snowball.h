#define SNOW_THING "The snow ball thing"
#define SNOW_EXTRA "/std/environ/snowball_look"
