/*  -*- LPC -*-  */
/*
 * $Locker:  $
 * $Id: path.h,v 1.1 1998/01/06 04:03:23 ceres Exp $
 * $Log: path.h,v $
 * Revision 1.1  1998/01/06 04:03:23  ceres
 * Initial revision
 * 
*/
#define HERE "/std/curses/"
