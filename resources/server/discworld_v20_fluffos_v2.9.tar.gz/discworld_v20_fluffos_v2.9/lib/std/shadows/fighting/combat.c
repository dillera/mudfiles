/*  -*- LPC -*-  */
/*
 * $Locker:  $
 * $Id: combat.c,v 1.8 2002/11/17 03:10:47 ceres Exp $
 * $Log: combat.c,v $
 * Revision 1.8  2002/11/17 03:10:47  ceres
 * Out of date now
 *
 * Revision 1.7  2000/06/29 01:09:32  pinkfish
 * Change around how concentrate works.
 *
 * Revision 1.6  2000/06/08 14:33:54  terano
 * Fixed misc things including initialising an array and adding an #include
 *
 * Revision 1.5  2000/06/08 01:48:53  pinkfish
 * Fix up some stuff.
 *
 * Revision 1.4  2000/05/07 09:54:56  ceres
 *  Forcibly unlocked by terano
 *
 * Revision 1.3  2000/03/23 03:56:07  taffyd
 * ADded is_fighting() function
 *
 * Revision 1.2  1998/06/12 20:56:25  ceres
 * Fixed but with using write instead of tell_object
 *
 * Revision 1.1  1998/01/06 04:36:31  ceres
 * Initial revision
 * 
*/
#include <obj_parser.h>

inherit "/std/effect_shadow";
