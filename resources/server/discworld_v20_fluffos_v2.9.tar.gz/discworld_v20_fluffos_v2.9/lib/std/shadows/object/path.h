#define PATH "/std/shadows/object/"
#undef EFFECTS
#define EFFECTS "/std/effects/object/"
