/*  -*- LPC -*-  */
/*
 * $Locker:  $
 * $Id: path.h,v 1.1 2000/05/01 03:10:24 jeremy Exp $
 *
 *
 */

#define FIXED_SHADOW "/std/room/basic/topography/fixed_shadow"
