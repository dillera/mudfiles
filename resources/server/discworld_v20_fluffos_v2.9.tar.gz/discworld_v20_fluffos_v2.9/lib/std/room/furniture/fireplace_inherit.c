inherit "/std/room/furniture/fireplace";

