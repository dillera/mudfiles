inherit "/std/races/human";

/* This is just the standard race ... but because of the problem with
   things being inherited, this is needed for now */
