/**
 * The inheritable for commercial player housing.
 * @author Pinkfish
 * @started Sat Jun  2 19:29:07 PDT 2001
 */
inherit "/std/shops/inherit/commercial";
