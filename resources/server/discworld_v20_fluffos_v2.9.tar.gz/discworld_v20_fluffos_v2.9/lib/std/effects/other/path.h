#define PATH "/std/effects/other/"

#define SHADOWS "/std/shadows/other/"
