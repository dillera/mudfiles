void bing() {
    int x;
    (: x :);
}
