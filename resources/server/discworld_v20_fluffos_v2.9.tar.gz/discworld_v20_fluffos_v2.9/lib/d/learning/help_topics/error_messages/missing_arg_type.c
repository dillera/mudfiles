void bing(x) {
}
