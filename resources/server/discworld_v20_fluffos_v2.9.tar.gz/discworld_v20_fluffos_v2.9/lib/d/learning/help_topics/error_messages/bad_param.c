void bing() {
    (: $-1 :);
}
