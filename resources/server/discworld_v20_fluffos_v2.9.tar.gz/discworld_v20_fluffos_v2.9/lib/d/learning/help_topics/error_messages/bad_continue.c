void bing() {
    continue;
}

/* continue belongs in for, foreach and while loops, not by itself
 */
