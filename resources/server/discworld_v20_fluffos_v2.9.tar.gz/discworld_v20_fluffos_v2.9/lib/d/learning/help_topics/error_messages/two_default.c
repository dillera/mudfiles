void bing() {
    switch (1) {
    default:
    default:
    }
}
