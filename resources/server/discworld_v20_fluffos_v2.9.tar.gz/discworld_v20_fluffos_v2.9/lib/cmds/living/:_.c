/*  -*- LPC -*-  */
/*
 * $Locker:  $
 * $Id: :_.c,v 1.2 1999/05/04 23:24:03 pinkfish Exp $
 * $Log: :_.c,v $
 * Revision 1.2  1999/05/04 23:24:03  pinkfish
 * Fix up the way this works.
 *
 * Revision 1.1  1998/01/06 05:28:43  ceres
 * Initial revision
 * 
*/
inherit "/cmds/living/em_ote";
