/** 
 * nslookup command.
 * Links to the host command.
 */

inherit "/cmds/creator/host";

