#include <virtual.h>

#define SERVER "/global/virtual/server"

#define LOAD   1
#define CLONE  2
