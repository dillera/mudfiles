#define ARTIFACT_HAND "/obj/handlers/artifact_handler"

#define RING_SKILL "magic.items.worn.ring"
#define STAFF_SKILL "magic.items.held.staff"
#define WAND_SKILL "magic.items.held.wand"

#define RING_OBJECT "/obj/ring"
#define STAFF_OBJECT "/obj/staff"
#define WAND_OBJECT "/obj/wand"
