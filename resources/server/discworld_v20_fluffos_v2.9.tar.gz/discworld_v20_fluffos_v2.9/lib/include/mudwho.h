#ifndef __SYS__MUDWHO
#define __SYS__MUDWHO

#define CMWHOD "/net/daemon/cmwhod"

#endif /* __SYS__MUDWHO */
