#define WEEZENT                "/d/sur/Weezent/"

#define BETWEENS               WEEZENT +"betweens/"
#define UNIQUES                WEEZENT +"uniques/"

#define GRFLX_NEST             WEEZENT +"grflx_nest/"
#define UNDER_WELL             WEEZENT +"under_well/"
#define VILLAGE                WEEZENT +"village/"

#define CHARS                  WEEZENT +"chars/"
#define ITEMS                  WEEZENT +"items/"
#define UTILS                  WEEZENT +"utils/"

#define HOSPITAL               ( WEEZENT +"hospital" )
