void do_tests() {
    // more later
}
