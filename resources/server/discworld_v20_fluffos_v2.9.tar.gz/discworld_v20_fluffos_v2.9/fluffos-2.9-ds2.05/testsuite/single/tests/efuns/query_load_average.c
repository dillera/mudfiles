void do_tests() {
    ASSERT(stringp(query_load_average()));
}

