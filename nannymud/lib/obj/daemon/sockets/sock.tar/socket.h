#include <socket_errors.h>
#define MUD 0
#define STREAM 1
#define DATAGRAM 2
