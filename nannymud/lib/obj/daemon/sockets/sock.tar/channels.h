#define CHANNEL_D "/cmds/channels/std/channels"

#define NO_CHANNEL	0
#define QUIET_ALL	1
#define QUIET_PLAY	2
#define CHAN_WIZ	4
#define CHAN_GOSSIP	8
#define CHAN_Q_AND_A	16
#define CHAN_MUDLIB	32
#define CHAN_DRIVER	64
#define CHAN_DOC	128
#define CHAN_INTERMUD   256
#define CHAN_INTERWIZ 512
#define CHAN_CON 1024
